﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace MOVEArdisVitta
{
	internal class Leitura
	{
		public string ARQUIVOS(string caminho_args) //Metodo que le os arquivos para conversao
		{
			try
			{
				//Variaveis
				string[] arquivos = Directory.GetFiles(caminho_args, "*.*" , SearchOption.AllDirectories);
				//string PastaBNest = @"C:\\Users\\User\\Desktop\\Maquina\\BNest";
				//string PastaProgetti = @"C:\\Users\\User\\Desktop\\Maquina\\Progetti";
				string PastaBNest = @"\\BS-1000046733\\bNest";
				string PastaProgetti = @"\\BS-1000046733\\progetti";
				string NomePastaOriginal;
				List<string> lista_arquivosCIX = new List<string>();
				List<string> lista_arquivosBWKL = new List<string>();
				List<string> lista_arquivosXML = new List<string>();
				List<string> lista_arquivosR41 = new List<string>();

				//Calculos
				foreach (var item in arquivos)
				{	
					if (item.EndsWith("CIX") || item.EndsWith("cix"))
					{
						lista_arquivosCIX.Add(item);
					}
					
					if(item.EndsWith("BWKL") || item.EndsWith("bwkl"))
					{
						lista_arquivosBWKL.Add(item);
					}
					
					if (item.EndsWith("XML") || item.EndsWith("xml"))
					{
						lista_arquivosXML.Add(item);
					}
					
					if(item.EndsWith("R41") || item.EndsWith("r41"))
					{
						lista_arquivosR41.Add(item);
					}
				}

				for (int i = 0; i < lista_arquivosR41.Count; i++)
				{
					NomePastaOriginal = Directory.GetParent(lista_arquivosR41[i]).Name;
					string novaPastaBNest = PastaBNest + @"\" + NomePastaOriginal;
					string novaPastaProgetti = PastaProgetti;
					Directory.CreateDirectory(novaPastaBNest);

					for (int j = 0; j < lista_arquivosCIX.Count; j++)
					{
						string arquivoTotal = lista_arquivosCIX[j];
						string nomeArquivo = new DirectoryInfo(arquivoTotal).Name;
						string nomeArquivoNovo = novaPastaBNest + @"\" + nomeArquivo;
						File.Delete(nomeArquivoNovo);
						File.Copy(arquivoTotal, nomeArquivoNovo);
					}

					for (int k = 0; k < lista_arquivosBWKL.Count; k++)
					{
						string arquivoTotal = lista_arquivosBWKL[k];
						string nomeArquivo = new DirectoryInfo(arquivoTotal).Name;
						string nomeArquivoNovo = novaPastaBNest + @"\" + nomeArquivo;
						File.Delete(nomeArquivoNovo); 
						File.Copy(arquivoTotal, nomeArquivoNovo);
					}

					for (int m = 0; m < lista_arquivosR41.Count; m++)
					{
						string arquivoTotal = lista_arquivosR41[m];
						string nomeArquivo = new DirectoryInfo(arquivoTotal).Name;
						string nomeArquivoNovo = novaPastaBNest + @"\" + nomeArquivo;
						File.Delete(nomeArquivoNovo); 
						File.Copy(arquivoTotal, nomeArquivoNovo);
					}

					for (int n = 0; n < lista_arquivosXML.Count; n++)
					{
						string arquivoTotal = lista_arquivosXML[n];
						string nomeArquivo = new DirectoryInfo(arquivoTotal).Name;
						string nomeArquivoNovo = novaPastaProgetti + @"\" + nomeArquivo;

						if (Directory.Exists(novaPastaProgetti))
						{
							File.Delete(nomeArquivoNovo); 
							File.Copy(arquivoTotal, nomeArquivoNovo);
						}
						else
						{
							Directory.CreateDirectory(novaPastaProgetti);
							File.Copy(arquivoTotal, nomeArquivoNovo);
						}
					}
				}

				return caminho_args;
			}
			catch (Exception e)
			{
				MessageBox.Show(e.ToString(), "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				throw;
			}
		}
	}
}
